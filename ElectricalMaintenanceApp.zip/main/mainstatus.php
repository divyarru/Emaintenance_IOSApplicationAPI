<!DOCTYPE html>
<html lang="en">
<head>
    <style>
     body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        header {
            background-color: #1c0d3f;
            color: white;
            padding: 1px;
            text-align: center;
        }

        nav {
            background-color: #1c0d3f;
            color: white;
            padding: 1px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            display: inline;
            margin-right: 20px;
            font-size: 13px;
        }

        a {
            text-decoration: none;
            color: white;
        }

        main {
            padding: 20px;
        }

        section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        section h2 {
            text-align: center;
        }

        h2 {
            margin-top: 0;
        }

        form {
            border: 1px solid #ccc;
            padding: 20px;
            max-width: 400px;
            margin: 0 auto;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-size: 13px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 13px;
        }

        button {
            background-color: #1c0d3f;
            color: #fff;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 13px;
        }

        button:hover {
            background-color: #001f3f;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: #1c0d3f;
            color: white;
            text-align: center;
            padding: 10px;
        }

        select#viewSelect {
        font-size: 12px; /* Adjust the font size as needed */
        padding: 5px;
        width: 10%;    /* Adjust the padding as needed */
    }

    .section-separator {
        margin-top: 20px;
    }
    </style>
</head>
<body>
    <header style="background-color: #1c0d3f; color: white; text-align: center; padding: 10px;">
        <h2>Status</h2>
    </header>

    <nav>
    <ul>
        <li><a href="supervisordashboard.php">Home</a></li>
        <li><a href="supervisoremployedetails.php">Employee Details</a></li>
        <li><a href="viewissue.php">View Issue</a></li>
        <li><a href="choose.php">Assign Issue</a></li>
        <li><a href="mainstatus.php">Status</a></li>
        <li><a href="mainlogin.php">Logout</a></li>
    </ul>
</nav>
    <div style="text-align: center; margin-top: 10px;">
        <label for="viewSelect">View:</label>
        <select id="viewSelect" onchange="filterTasks()">
            <option value="all">All</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
        </select>
    </div>

    <?php
    // Database connection
    $conn = mysqli_connect("localhost", "root", "", "maintanence");
    session_start();

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to fetch tasks from the database
    $sql = "SELECT  name,status,empid,servicetype FROM job";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $name = $row['name'];
            $empid = $row['empid'];
            $status = $row['status'];
            $servicetype = $row['servicetype'];


            // Determine the appropriate CSS class based on task status
            $taskClass = ($status == 'completed') ? 'task completed' : 'task';

            // Output section bar with spacing
            echo "<div class='section-separator'></div>";
            echo "<section class='$taskClass' data-status='$status'>";
            echo "<div style='background-color: #3333; color: black; padding: 10px;'>";
            echo "<h4>$name</h4>";
            echo "<p>empid: $empid</p>";
            echo "<p>Status: $status</p>";
            echo "<p>Issue: $servicetype</p>";
            if ($status == 'pending') {
                echo "<button onclick=\"finishTask('$empid')\">Finish</button>";
            }
            echo "</div>";
            echo "</section>";
        }
    }
    // Close the database connection
    $conn->close();
    ?>
    

    <script>
        // JavaScript function to filter tasks based on the "View" dropdown
        function filterTasks() {
            const viewSelect = document.getElementById('viewSelect');
            const status = viewSelect.value;
            const tasks = document.querySelectorAll('.task');

            tasks.forEach(task => {
                const taskStatus = task.getAttribute('data-status');
                if (status === 'all') {
                    task.style.display = 'block';
                } else if (status === 'pending' && taskStatus === 'pending') {
                    task.style.display = 'block';
                } else if (status === 'completed' && taskStatus === 'completed') {
                    task.style.display = 'block';
                } else {
                    task.style.display = 'none';
                }
            });
        }

        // JavaScript function to mark a task as finished
        function finishTask(empid) {
            // You can perform an action here to update the status in the database
            alert("Task with Employee ID " + empid + " has been marked as finished.");
            // You can also reload the page or update the task status dynamically
        }

        // Initial call to filter tasks based on the "View" dropdown
        filterTasks();
    </script>
</body>
</html>
