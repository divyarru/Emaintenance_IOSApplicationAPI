<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Job to Worker</title>
    <style>
        /* CSS styles for the employee table */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        header {
            background-color: #1c0d3f;
            color: white;
            padding: 1px;
            text-align: center;
        }

        nav {
            background-color: #311249;
            color: white;
            padding: 1px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
        }
        
        ul a {
            color: white;
        }

        li {
            display: inline;
            margin-right: 20px;
            color: white;
            font-size: 13px;
        }

        a {
            text-decoration: none;
            color: #1c0d3f
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            font-size: 13px;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        select,
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button {
            background-color: #1c0d3f;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
        }
    </style>
</head>
<header>
        <h2>Electrical Maintenance</h2>
    </header>
    
    <nav>
        <ul>
        <li><a href="supervisordashboard.php">Home</a></li>
            <li><a href="viewissue.php">View Issue</a></li>
            <li><a href="choose.php">Assign Issue</a></li>
            <li><a href="mainstatus.php">Work Status</a></li>
            <li><a href="Rating.php">Rating</a></li>
            <li><a href="workerprofile.php">My Profile</a></li>
            <li><a href="mainlogin.php">Logout</a></li>
        </ul>
    </nav>
    <br><br>

<body>
    <form method="post" action="">
        <h1>Assign Job to Worker</h1>

        <?php
        $conn = mysqli_connect("localhost", "root", "", "maintanence");

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Fetch workers from login table
        $query = "SELECT username, name FROM login WHERE role='worker' AND action = 'active'";
        $result = mysqli_query($conn, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            echo '<label for="worker">Choose Worker:</label>';
            echo '<select name="worker" id="worker">';
            while ($row = mysqli_fetch_assoc($result)) {
                $username = $row['username'];
                $name = $row['name'];
                echo "<option value='$username'>$name</option>";
            }
            echo '</select>';
        } else {
            echo 'No workers available';
        }

        // Fetch equipment IDs from eqdetails table
        $eqQuery = "SELECT eid FROM eqdetails";
        $eqResult = mysqli_query($conn, $eqQuery);

        if ($eqResult && mysqli_num_rows($eqResult) > 0) {
            echo '<label for="eid">Choose Equipment ID:</label>';
            echo '<select name="eid" id="eid">';
            while ($eqRow = mysqli_fetch_assoc($eqResult)) {
                $eid = $eqRow['eid'];
                echo "<option value='$eid'>$eid</option>";
            }
            echo '</select>';
        } else {
            echo 'No equipment IDs available';
        }
        ?>

        <label for="servicetype">Issue:</label>
        <input type="text" id="servicetype" name="servicetype" required>

        <label for="date">Date:</label>
        <input type="date" name="date" required>

        <label for="location">Location:</label>
        <input type="text" name="location" required>

        <button type="submit" name="assign">Assign Job</button>
    </form>

    <?php
    // ... Your existing code ...
    
    if (isset($_POST['assign'])) {
        $servicetype = mysqli_real_escape_string($conn, $_POST['servicetype']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);
        $location = mysqli_real_escape_string($conn, $_POST['location']);
        $eid = mysqli_real_escape_string($conn, $_POST['eid']);
        $workerUsername = mysqli_real_escape_string($conn, $_POST['worker']);
    
        // Fetch the corresponding worker name based on the selected username
        $workerQuery = "SELECT name FROM login WHERE username='$workerUsername'";
        $workerResult = mysqli_query($conn, $workerQuery);
    
        if ($workerResult && mysqli_num_rows($workerResult) > 0) {
            $workerRow = mysqli_fetch_assoc($workerResult);
            $workerName = $workerRow['name'];
    
            // Insert the job with the worker's name and username
            $sql = "INSERT INTO job (servicetype, date, location, eid2, name, empid) 
                    VALUES ('$servicetype', '$date', '$location', '$eid', '$workerName', '$workerUsername')";
    
            if (mysqli_query($conn, $sql)) {
                echo '<script>alert("Job assigned successfully!");</script>';
            } else {
                echo 'Error assigning job: ' . mysqli_error($conn);
            }
        } else {
            echo 'Error fetching worker information: ' . mysqli_error($conn);
        }
    }
    
    // ... Your existing code ...
    ?>
    
</body>

</html>
