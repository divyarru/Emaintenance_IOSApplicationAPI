<?php
session_start();
$user = $_SESSION["username"];

$conn = mysqli_connect("localhost", "root", "", "maintanence");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to retrieve data from the 'login' table
$sql = "SELECT * FROM issue where user_id= '$user' AND status != 'completed'";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search and Buttons Example</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        header {
            background-color: #1c0d3f;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav {
            background-color: #1c0d3f;
            color: white;
            padding: 10px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            display: inline;
            margin-right: 20px;
            font-size: 13px;
        }

        a {
            text-decoration: none;
            color: white;
        }
        .employee-table {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .employee-table h3 {
            margin-top: 0;
        }

        .employee-table table {
            width: 100%;
            border-collapse: collapse;
        }

        .employee-table th, .employee-table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
            font-size: 13px;
        }

        .employee-table th {
            background-color: #f2f2f2;
        }

    </style>
    <style>
        
/* CSS */
.button-40 {
  background-color: #111827;
  border: 1px solid transparent;
  border-radius: .65rem;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  flex: 0 0 auto;
  font-family: "Inter var", ui-sans-serif, system-ui, -apple-system, system-ui, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
  font-size: 13px; /* Adjusted font size */
  font-weight: 500;
  line-height: 0.9rem;
  padding: .5rem 1rem; /* Adjusted padding */
  text-align: center;
  text-decoration: none #6B7280 solid;
  text-decoration-thickness: auto;
  transition-duration: .2s;
  transition-property: background-color, border-color, color, fill, stroke;
  transition-timing-function: cubic-bezier(.4, 0, 0.2, 1);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  width: auto;

}

.button-40:hover {
  background-color: #374151;
}

.button-40:focus {
  box-shadow: none;
  outline: 2px solid transparent;
  outline-offset: 2px;
}

@media (min-width: 768px) {
  .button-40 {
    padding: .4rem 1rem; /* Adjusted padding */
    font-size: 1.115rem; /* Reset font size for larger screens */
  }
}

    </style>
</head>
<body>
<nav>
    <ul>
    <li><a href="issue.php">Raise Issue</a></li>
        <li><a href="mainlogin.php">Logout</a></li>
    </ul>
</nav>
<br><br>

    </style>
</head>
<body>
    <nav>
        <!-- Navigation menu if needed -->
    </nav>

    <main>
        <div class="employee-table">
            <h3>Issue Details</h3>
            <table>
                <thead>
                    <tr>
                        <th>Location</th>
                        <th>Equipment</th>
                        <th>Issue</th>
                        <th>Action</th>

                    </tr>
                </thead>
                <tbody>
                    <!-- Loop through the data retrieved from the database -->
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['location'] . "</td>";
                        echo "<td>" . $row['eqname'] . "</td>";
                        echo "<td>" . $row['issue'] . "</td>";
                        echo "<td><a href='approve.php?id=" . $row['iid'] . "'><button class='button-40' role='button'>Close Issue</button></a>
                        </td>";
                        


                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
</body>
</html>
