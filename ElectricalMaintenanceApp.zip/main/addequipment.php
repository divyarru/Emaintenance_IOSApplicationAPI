<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Location</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        header {
            background-color: #1c0d3f;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav {
            background-color: #1c0d3f;
            color: white;
            padding: 10px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            display: inline;
            margin-right: 20px;
            font-size: 13px;
        }

        a {
            text-decoration: none;
            color: white;
        }

        main {
            padding: 20px;
        }

        section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        section h2 {
            text-align: center;
        }

        h2 {
            margin-top: 0;
        }

        form {
            border: 1px solid #ccc;
            padding: 20px;
            max-width: 400px;
            margin: 0 auto;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-size: 13px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            background-color: #1c0d3f;
            color: #fff;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 13px;
        }

        button:hover {
            background-color: #001f3f;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: #1c0d3f;
            color: white;
            text-align: center;
            padding: 10px;
        }
    </style>
</head>
<body>

<nav>
    <ul>
        <li><a href="appdashboard.php">Home</a></li>
        <li><a href="mainlogin.php">Logout</a></li>
    </ul>
</nav>
<br><br>

<?php
$conn = mysqli_connect("localhost", "root", "", "maintanence");

if (isset($_POST['Submit'])) {
    $eid = $_POST['eid'];

    // Check if the record with the same Item Id already exists
    $checkSql = "SELECT * FROM eqdetails WHERE eid='$eid'";
    $checkResult = mysqli_query($conn, $checkSql);

    if (mysqli_num_rows($checkResult) > 0) {
        echo "Error: Item Id already exists. Please provide a different Item Id.";
    } else {
        // Proceed with data insertion if no duplicate record is found
        $name = $_POST['name'];
        $brand = $_POST['brand'];
        $price = $_POST['price'];
        $installation = $_POST['installation'];
        $warranty = $_POST['warranty'];
        $warrantyend = $_POST['warrantyend'];
        $building = $_POST['building'];
        $room = $_POST['room'];
       

        // Insert selected location details into the "location" table
        $locationSql = "INSERT INTO location (eidd, building, room, equipment) 
                        VALUES ('$eid', '$building', '$room', '$name')";
        $locationData = mysqli_query($conn, $locationSql);

        // Insert selected equipment details into the "eqdetails" table
        $eqDetailsSql = "INSERT INTO eqdetails (eid, name, brand, price, installation, warranty, warrantyend ) 
                         VALUES ('$eid', '$name', '$brand', '$price', '$installation', '$warranty', '$warrantyend')";
        $eqDetailsData = mysqli_query($conn, $eqDetailsSql);

        if ($locationData && $eqDetailsData) {
            // Insert the equipment ID into the job table as eid2
            $jobSql = "INSERT INTO job (eid2) VALUES ('$eid')";
            $jobData = mysqli_query($conn, $jobSql);
        
            if ($jobData) {
                echo "Details Added successfully";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }  
}
?>


<main>
    <section>
        <h2>Add Equipment Details</h2>
        <form method="post" action="">
            <label for="eid">Item Id</label>
            <input type="text" id="eid" name="eid" required>

            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>

            <label for="brand">Brand:</label>
            <input type="text" id="brand" name="brand" required>

            <label for="price">Price</label>
            <input type="text" id="price" name="price" required>

            <label for="installation">Purchase Date</label>
            <input type="date" id="installation" name="installation" required>

            <label for="warranty">Warranty Period:</label>
            <input type="text" id="warranty" name="warranty" required>

            <label for="warrantyend">Warranty Endby:</label>
            <input type="date" id="warrantyend" name="warrantyend" required>

            <!-- Add building and room fields -->
            <label for="building">Building</label>
            <input type="text" id="building" name="building" required>

            <label for="room">Room</label>
            <input type="text" id="room" name="room" required>

            <button type="submit" name="Submit">Submit</button>
        </form>
    </section>
</main>



</body>
<script>
    // Display a JavaScript alert only for the specific message
    var message = "<?php echo $message; ?>";
    if (message.includes("Item Id already exists")) {
        alert(message);
    }
</script>

</html>
