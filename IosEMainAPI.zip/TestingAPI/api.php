<?php
error_reporting(0);

require_once('dbconfig.php');

$loginqry = "SELECT * FROM eqdetails";

$qry = mysqli_query($dbconn, $loginqry);

if (mysqli_num_rows($qry) > 0) {
    $i = 0;
    while ($row = mysqli_fetch_assoc($qry)) {
        $student[$i]['eid'] = $row['eid'];
        $student[$i]['name'] = $row['name'];
        $student[$i]['brand'] = $row['brand'];
        $student[$i]['type'] = $row['type'];
        $student[$i]['price'] = $row['price'];
        $student[$i]['installation'] = $row['installation'];
        $student[$i]['warranty'] = $row['warranty'];
        $student[$i]['warrantyend'] = $row['warrantyend'];

        $i = $i + 1;
    }
    $response['status'] = true;
    $response['message'] = "Data retrieved successfully";
    $response['data'] = $student;
} else {
    $response['status'] = false;
    $response['message'] = "No data found";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
