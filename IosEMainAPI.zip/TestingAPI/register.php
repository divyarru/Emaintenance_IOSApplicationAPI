<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

/*$bioid = 10105;
$username = "Gyaan";
$password = "pass123";
$department = "MECH";
$attendance = "99";
$roomno = "G123";*/

$bioid = "";
$username = "";
$password = "";
$department = "";
$attendance = "";
$roomno = "";

$bioid  = $_POST['bioid'];
$username = $_POST['username'];
$password = $_POST['password'];
$department = $_POST['department'];
$attendance = $_POST['attendance'];
$roomno = $_POST['roomno'];
echo 'Bioid = ' .$bioid;
echo 'username = '.$username;

$error;
if(empty($bioid)){
	
	$error = "Bioid is Required";
}

else if(empty($username)){
	
	$error = "username is Required";
}
else if(empty($password)){
	
	$error = "Password is Required";
}
else if(empty($department)){
	
	$error = "Department is Required";
}
else if(empty($attendance)){
	
	$error = "Attendance is Required";
}
else if(empty($roomno)){
	
	$error = "Room Number is Required";
}
else {
	$bioidExist = mysqli_query($dbconn,"SELECT * FROM users WHERE bioid = $bioid");
	
	if(mysqli_num_rows($bioidExist) == 0){
	
	$insertData = "INSERT INTO users(bioid, username, password, department, attendance, roomno) VALUES('$bioid','$username','$password','$department','$attendance','$roomno')";
	
	$qry =mysqli_query($dbconn,$insertData) or die (json_encode(array("status" => false, "message" => mysqli_error($dbconn)))); 
	
	if($qry){
		$id = mysqli_insert_id($dbconn);
		$response['status'] = true;
		$response['message']= "Resgister Successfully";
		$response['UserId'] = $id;
	}
	else{
		
		$response['status'] = false;
		$response['message']= "Resgister Failed";
		
	}
	
	}

	else{
	$response['status'] = false;
	$response['message']= "Bioid Already Exist!...";
	
	}
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>