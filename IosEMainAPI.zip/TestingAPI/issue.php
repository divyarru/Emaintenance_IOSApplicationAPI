<?php
// Set the appropriate content type for JSON
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "maintanence");

    if (!$conn) {
        // If the connection fails, return an error response
        echo json_encode(['message' => 'Database connection failed']);
    } else {
        // Retrieve and sanitize data from the POST request
        $eqid = mysqli_real_escape_string($conn, $_POST['eqid']);
        $eqname = mysqli_real_escape_string($conn, $_POST['eqname']);
        $issue = mysqli_real_escape_string($conn, $_POST['issue']);
        $location = mysqli_real_escape_string($conn, $_POST['location']);
        $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);


        // SQL query to insert the employee into the database
        $sql = "INSERT INTO issue (eqid, eqname, issue, location, user_id, date) 
                VALUES ('$eqid', '$eqname', '$issue', '$location','$user_id','$date')";

        // Execute the query
        if (mysqli_query($conn, $sql)) {
            // If the insertion is successful, return a success response
            echo json_encode(['message' => 'Issue added successfully']);
        } else {
            // If there's an error with the query, return an error response
            echo json_encode(['message' => 'Failed to add Issue']);
        }

        // Close the database connection
        mysqli_close($conn);
    }
} else {
    // If the request method is not POST, return a message indicating the invalid request method
    echo json_encode(['message' => 'Invalid request method']);
}
?>