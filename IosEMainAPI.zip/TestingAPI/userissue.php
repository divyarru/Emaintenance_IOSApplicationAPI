<?php
error_reporting(0);
require_once('dbconfig.php');

$loginqry = "SELECT * FROM issue ";

$qry = mysqli_query($dbconn, $loginqry);

$response = array();

if (mysqli_num_rows($qry) > 0) {
    $i = 0;
    
    $student = array(); // Initialize an array to store the data

    while ($row = mysqli_fetch_assoc($qry)) {
        $student[$i]['user_id'] = $row['user_id'];
        $student[$i]['issue'] = $row['issue'];
        $student[$i]['eqname'] = $row['eqname'];
        $student[$i]['location'] = $row['location'];

        $i = $i + 1;
    }

    $response['status'] = true;
    $response['message'] = "Data Found";
    $response['data'] = $student;
} else {
    $response['status'] = false;
    $response['message'] = "No Data Found";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
