<?php
// Set the appropriate content type for JSON
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "maintanence");

    if (!$conn) {
        // If the connection fails, return an error response
        echo json_encode(['message' => 'Database connection failed']);
    } else {
        // Retrieve and sanitize data from the POST request
        $eid2 = mysqli_real_escape_string($conn, $_POST['eid2']);
        $servicetype = mysqli_real_escape_string($conn, $_POST['servicetype']);
        $servicecharge = mysqli_real_escape_string($conn, $_POST['servicecharge']);
        $empid = mysqli_real_escape_string($conn, $_POST['empid']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);

        // SQL query to insert the employee into the database
        $sql = "INSERT INTO job (eid2, servicetype, servicecharge, empid, date) 
                VALUES ('$eid2', '$servicetype', '$servicechrge', 'empid', '$date')";

        // Execute the query
        if (mysqli_query($conn, $sql)) {
            // If the insertion is successful, return a success response
            echo json_encode(['message' => 'Employee added successfully']);
        } else {
            // If there's an error with the query, return an error response
            echo json_encode(['message' => 'Failed to add employee']);
        }

        // Close the database connection
        mysqli_close($conn);
    }
} else {
    // If the request method is not POST, return a message indicating the invalid request method
    echo json_encode(['message' => 'Invalid request method']);
}
?>