<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

//$bioid = "";
//$password = "";

//$bioid=$_GET['bioid'];
//$password=$_GET['password'];

$loginqry = "SELECT * FROM login";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
	$student[$i]['name'] = $row['name'];
	$student[$i]['assignblock'] = $row['assignblock'];
	$student[$i]['mobno'] = $row['mobno'];
	
	
	$i = $i+1;
	}
	//$userObj = mysqli_fetch_assoc($qry);
	$response['status'] = true;
	$response['message']= "Login Successfully";
	$response['data'] = $student;	
}
else{
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>