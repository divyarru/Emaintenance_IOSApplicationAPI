<?php
require_once('dbconfig.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $eid2 = $_POST['eid2'];
    $servicetype = $_POST['servicetype'];
    $servicecharge = $_POST['servicecharge'];
    $empid = $_POST['empid'];
    $date = $_POST['date'];
    $status = $_POST['status'];


    $insertData = "INSERT INTO job (eid2, servicetype, servicecharge, empid, date, status) VALUES('$eid2', '$servicetype', '$servicecharge', '$empid', '$date', '$status')";

    $response = array();

    if(mysqli_query($dbconn, $insertData)){
        $id = mysqli_insert_id($dbconn);
        $response['status'] = 'success';
        $response['message'] = 'Register Successfully';
        // You can include additional data in the response if needed
        // $response['u_id'] = $id;
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Register Failed';
        // You can include an error message if needed
        // $response['error'] = mysqli_error($dbconn);
    }

    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($response);
}
?>