<?php
// Set the appropriate content type for JSON
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "maintanence");

    if (!$conn) {
        // If the connection fails, return an error response
        echo json_encode(['message' => 'Database connection failed']);
    } else {
        // Retrieve and sanitize data from the POST request
        $building = mysqli_real_escape_string($conn, $_POST['building']);
        $floor = mysqli_real_escape_string($conn, $_POST['floor']);
        $room = mysqli_real_escape_string($conn, $_POST['room']);
        $eidd = mysqli_real_escape_string($conn, $_POST['eidd']);

        // SQL query to insert the employee into the database
        $sql = "INSERT INTO location (building, floor, room, eidd) 
                VALUES ('$building', '$floor', '$room', '$eidd')";

        // Execute the query
        if (mysqli_query($conn, $sql)) {
            // If the insertion is successful, return a success response
            echo json_encode(['message' => 'Employee added successfully']);
        } else {
            // If there's an error with the query, return an error response
            echo json_encode(['message' => 'Failed to add employee']);
        }

        // Close the database connection
        mysqli_close($conn);
    }
} else {
    // If the request method is not POST, return a message indicating the invalid request method
    echo json_encode(['message' => 'Invalid request method']);
}
?>